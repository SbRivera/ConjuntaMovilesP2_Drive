import 'dart:convert';
import 'package:http/http.dart' as http;
import '../modelo/verdura.dart';

class VerduraController {
  final String baseUrl = "http://10.40.13.87:3000";

  // Obtener todas las verduras
  Future<List<Verdura>> obtenerVerduras() async {
    final response = await http.get(Uri.parse("$baseUrl/json"));

    if (response.statusCode == 200) {
      List<dynamic> data = json.decode(response.body);
      return data.map((item) => Verdura.fromJson(item)).toList();
    } else {
      throw Exception("Error al obtener las verduras");
    }
  }

  // Añadir una nueva verdura
  Future<void> agregarVerdura(Verdura verdura) async {
    final response = await http.post(
      Uri.parse("$baseUrl/json"),
      headers: {"Content-Type": "application/json"},
      body: json.encode(verdura.toJson()),
    );

    if (response.statusCode != 201) {
      throw Exception("Error al añadir la verdura");
    }
  }

  // Eliminar una verdura
  Future<void> eliminarVerdura(int codigo) async {
    final response = await http.delete(Uri.parse("$baseUrl/json/$codigo"));

    if (response.statusCode != 200) {
      throw Exception("Error al eliminar la verdura");
    }
  }

  // Editar una verdura existente
  Future<void> editarVerdura(int codigo, Verdura verdura) async {
    final response = await http.put(
      Uri.parse("$baseUrl/json/$codigo"),
      headers: {"Content-Type": "application/json"},
      body: json.encode(verdura.toJson()),
    );

    if (response.statusCode != 200) {
      throw Exception("Error al editar la verdura");
    }
  }
}
