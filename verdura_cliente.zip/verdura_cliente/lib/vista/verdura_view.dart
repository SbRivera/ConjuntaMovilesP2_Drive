import 'package:flutter/material.dart';
import '../modelo/verdura.dart';
import '../controlador/verdura_controller.dart';

class VerduraView extends StatefulWidget {
  @override
  _VerduraViewState createState() => _VerduraViewState();
}

class _VerduraViewState extends State<VerduraView> {
  final VerduraController _controller = VerduraController();
  List<Verdura> _verduras = [];
  final _descripcionController = TextEditingController();
  final _precioController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _cargarVerduras();
  }

  Future<void> _cargarVerduras() async {
    try {
      final verduras = await _controller.obtenerVerduras();
      setState(() {
        _verduras = verduras;
      });
    } catch (e) {
      print(e);
    }
  }

  Future<void> _agregarVerdura() async {
    final descripcion = _descripcionController.text;
    final precio = double.tryParse(_precioController.text);

    if (descripcion.isEmpty || precio == null) return;

    final nuevaVerdura = Verdura(
      codigo: _verduras.isEmpty ? 1 : _verduras.last.codigo + 1,
      descripcion: descripcion,
      precio: precio,
    );

    try {
      await _controller.agregarVerdura(nuevaVerdura);
      _descripcionController.clear();
      _precioController.clear();
      _cargarVerduras();
    } catch (e) {
      print(e);
    }
  }

  Future<void> _eliminarVerdura(int codigo) async {
    try {
      await _controller.eliminarVerdura(codigo);
      _cargarVerduras();
    } catch (e) {
      print(e);
    }
  }

  Future<void> _editarVerdura(int codigo) async {
    final descripcion = _descripcionController.text;
    final precio = double.tryParse(_precioController.text);

    if (descripcion.isEmpty || precio == null) return;

    final verduraEditada = Verdura(
      codigo: codigo,
      descripcion: descripcion,
      precio: precio,
    );

    try {
      await _controller.editarVerdura(codigo, verduraEditada);
      _descripcionController.clear();
      _precioController.clear();
      _cargarVerduras();
    } catch (e) {
      print(e);
    }
  }

  void _mostrarDialogo({Verdura? verdura}) {
    if (verdura != null) {
      _descripcionController.text = verdura.descripcion;
      _precioController.text = verdura.precio.toString();
    } else {
      _descripcionController.clear();
      _precioController.clear();
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(verdura == null ? "Añadir Verdura" : "Editar Verdura"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: _descripcionController,
              decoration: InputDecoration(labelText: "Descripción"),
            ),
            TextField(
              controller: _precioController,
              decoration: InputDecoration(labelText: "Precio"),
              keyboardType: TextInputType.number,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text("Cancelar"),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.of(context).pop();
              if (verdura == null) {
                await _agregarVerdura();
              } else {
                await _editarVerdura(verdura.codigo);
              }
            },
            child: Text(verdura == null ? "Añadir" : "Guardar"),
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white, backgroundColor: Colors.blue, // Color del texto blanco
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Text("Verduras"),
      ),
      body: ListView.builder(
        itemCount: _verduras.length,
        itemBuilder: (context, index) {
          final verdura = _verduras[index];
          return ListTile(
            title: Text(verdura.descripcion),
            subtitle: Text("\$${verdura.precio.toStringAsFixed(2)}"),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Icon(Icons.edit, color: Colors.blue),
                  onPressed: () => _mostrarDialogo(verdura: verdura),
                ),
                IconButton(
                  icon: Icon(Icons.delete, color: Colors.red),
                  onPressed: () => _eliminarVerdura(verdura.codigo),
                ),
              ],
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogo(),
        child: Icon(Icons.add),
      ),
    );
  }
}
