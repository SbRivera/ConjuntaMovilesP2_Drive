const { google } = require("googleapis");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
const { oAuth2Client, cargarToken, obtenerToken } = require("./auth");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const FILE_ID = "1tm6Tpr9Ktd48zO259LDpaogcBGIWs6D8";

// Ruta del token
const tokenPath = path.join(__dirname, "token.json");

// Verifica si el token existe
if (!fs.existsSync(tokenPath)) {
  console.log("No se encontró un token. Genera uno usando el flujo de autorización.");
  obtenerToken();
  process.exit(1);
}

cargarToken(); 

// Configurar el cliente de Google Drive
const drive = google.drive({ version: "v3", auth: oAuth2Client });

async function obtenerJSON() {
  try {
    const response = await drive.files.get({
      fileId: FILE_ID,
      alt: "media",
    });

    console.log("Respuesta de Google Drive:", response.data);

    if (typeof response.data === "string") {
      return JSON.parse(response.data);
    } else {
      return response.data;
    }
  } catch (error) {
    console.error("Error al obtener el archivo JSON:", error.message);
    throw new Error("No se pudo obtener el archivo JSON.");
  }
}

// Función para actualizar el archivo JSON en Google Drive
async function actualizarJSON(data) {
  const media = {
    mimeType: "application/json",
    body: JSON.stringify(data),
  };

  try {
    await drive.files.update({
      fileId: FILE_ID,
      media,
    });

    console.log("Archivo actualizado exitosamente.");
  } catch (error) {
    console.error("Error al actualizar el archivo JSON:", error.message);
    throw new Error("No se pudo actualizar el archivo JSON.");
  }
}

// Endpoints
app.get("/json", async (req, res) => {
  try {
    const data = await obtenerJSON();
    res.json(data);
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.delete("/json/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id, 10);
    let data = await obtenerJSON();

    // Eliminar el elemento del JSON
    data = data.filter((item) => item.codigo !== id);

    // Actualizar el archivo en Google Drive
    await actualizarJSON(data);

    res.json({ message: "Elemento eliminado con éxito." });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.post("/json", async (req, res) => {
  try {
    const nuevoElemento = req.body; 
    let data = await obtenerJSON(); 

    const existe = data.some((item) => item.codigo === nuevoElemento.codigo);
    if (existe) {
      return res.status(400).json({ message: "Ya existe un elemento con el mismo código." });
    }

    
    data.push(nuevoElemento);

  
    await actualizarJSON(data);

    res.status(201).json({ message: "Elemento agregado con éxito." });
  } catch (error) {
    res.status(500).send(error.message);
  }
});

app.put("/json/:codigo", async (req, res) => {
  try {
    const codigo = parseInt(req.params.codigo, 10); 
    const datosActualizados = req.body; 
    let data = await obtenerJSON(); 

    // Buscar el índice del elemento con el código especificado
    const indice = data.findIndex((item) => item.codigo === codigo);

    if (indice === -1) {
      return res.status(404).json({ message: "Elemento no encontrado." });
    }

    // Actualizar los datos del elemento
    data[indice] = {
      ...data[indice], 
      ...datosActualizados, 
    };

    // Actualizar el archivo JSON en Google Drive
    await actualizarJSON(data);

    res.status(200).json({ message: "Elemento actualizado con éxito.", elemento: data[indice] });
  } catch (error) {
    res.status(500).send(error.message);
  }
});


// Arrancar el servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
