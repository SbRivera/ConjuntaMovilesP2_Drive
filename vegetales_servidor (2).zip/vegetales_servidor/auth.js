const { google } = require("googleapis");
const fs = require("fs");
const path = require("path");

// Carga las credenciales de OAuth
const credentialsPath = path.join(__dirname, "credentials.json");
const credentials = JSON.parse(fs.readFileSync(credentialsPath, "utf-8"));

// Configura el cliente OAuth
const { client_id, client_secret, redirect_uris } = credentials.installed;
const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

// Obtén un token de acceso
function obtenerToken() {
  const authUrl = oAuth2Client.generateAuthUrl({
    access_type: "offline",
    scope: ["https://www.googleapis.com/auth/drive"],
  });

  console.log("Autoriza esta aplicación visitando esta URL:", authUrl);
}

// Guarda el token en un archivo
async function guardarToken(code) {
  try {
    const { tokens } = await oAuth2Client.getToken(code);
    oAuth2Client.setCredentials(tokens);
    fs.writeFileSync("token.json", JSON.stringify(tokens));
    console.log("Token almacenado con éxito.");
  } catch (error) {
    console.error("Error al guardar el token:", error.message);
  }
}

// Usa el token almacenado para autenticación
function cargarToken() {
  const tokenPath = path.join(__dirname, "token.json");
  if (fs.existsSync(tokenPath)) {
    const token = JSON.parse(fs.readFileSync(tokenPath, "utf-8"));
    oAuth2Client.setCredentials(token);
  } else {
    console.log("No se encontró un token. Ejecuta obtenerToken() para generar uno.");
  }
}

module.exports = { oAuth2Client, obtenerToken, guardarToken, cargarToken };
